/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Encriptador;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author valdemar
 */
public class EncriptadorRSA {
    
    private KeyPairGenerator geradorParChaves;
    private PublicKey chavePublica;
    private PrivateKey chavePrivada;
    
    public EncriptadorRSA(){
        try {
            geradorParChaves = KeyPairGenerator.getInstance("RSA");
            geradorParChaves.initialize(512);
            
            KeyPair parChave = geradorParChaves.generateKeyPair();
            
            this.chavePublica = parChave.getPublic();
            this.chavePrivada = parChave.getPrivate();
            
        } catch (NoSuchAlgorithmException ex) {
            System.out.println("Erro na instancia do Algoritmo RSA");
        }
    }
    
    public EncriptadorRSA(PublicKey chave_publica){
        this.chavePublica = chave_publica;
    }
    
    public KeyPair gerarChaves(){
        return geradorParChaves.generateKeyPair();
    }
    
    public byte[] encriptar(byte[] mensagem, PublicKey chave){
        
        try {
            Cipher cifra = Cipher.getInstance("RSA/ECB/NoPadding");
            cifra.init(Cipher.ENCRYPT_MODE, chave);
            return cifra.doFinal(mensagem);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException ex) {
            System.out.println("Erro no metodo encriptar: " + ex);
        }
        return null;
    }
    
    public byte[] encriptarRepartido(byte[] mensagem, PublicKey chave) {
        try {
            Cipher cifra = Cipher.getInstance("RSA/ECB/NoPadding");
            cifra.init(Cipher.ENCRYPT_MODE, chave);

            int tamanhoMaximoBloco = ((chave.getEncoded().length * 8) + 7) / 8; // Tamanho máximo em bytes
            int numBlocos = (mensagem.length + tamanhoMaximoBloco - 1) / tamanhoMaximoBloco;

            // Criar um buffer para armazenar o resultado da criptografia
            byte[] resultadoCriptografia = new byte[numBlocos * tamanhoMaximoBloco];

            // Criptografar cada bloco separadamente
            for (int i = 0; i < numBlocos; i++) {
                int tamanhoBloco = Math.min(tamanhoMaximoBloco, mensagem.length - i * tamanhoMaximoBloco);
                byte[] bloco = new byte[tamanhoBloco];
                System.arraycopy(mensagem, i * tamanhoMaximoBloco, bloco, 0, tamanhoBloco);
                byte[] criptografado = cifra.doFinal(bloco);
                System.arraycopy(criptografado, 0, resultadoCriptografia, i * tamanhoMaximoBloco, criptografado.length);
            }

            return resultadoCriptografia;
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException
                | BadPaddingException | IllegalBlockSizeException ex) {
            System.out.println("Erro no metodo encriptar: " + ex);
        }
        return null;
    }
    
    public static byte[] desencriptar(byte[] mensagemEncriptada, PrivateKey chave){
        try {
            Cipher cifra = Cipher.getInstance("RSA/ECB/NoPadding");
            cifra.init(Cipher.DECRYPT_MODE, chave);
            return cifra.doFinal(mensagemEncriptada);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException ex) {
            System.out.println("Erro no metodo desencriptar: " + ex);
        }
        return null;
    }

    public PublicKey getChavePublica() {
        return chavePublica;
    }

    public void setChavePublica(PublicKey chavePublica) {
        this.chavePublica = chavePublica;
    }

    public PrivateKey getChavePrivada() {
        return chavePrivada;
    }
    
}
