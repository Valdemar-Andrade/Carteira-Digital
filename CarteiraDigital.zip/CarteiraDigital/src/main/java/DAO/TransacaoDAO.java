/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.TransacaoView;

/**
 *
 * @author valdemar
 */
public class TransacaoDAO {

    public ArrayList<TransacaoView> listarTransacoesUsuario(String pk) {
        ArrayList<TransacaoView> listaTransacoes = new ArrayList<>();
        int pk_login = 0;

        pk_login = Integer.parseInt(pk);

        String query = "SELECT pessoa_origem.nome_completo AS nome_origem, pessoa_destino.nome_completo AS nome_destino, t.descricao, t.data, ti.descricao AS tipo, t.valor FROM transacao t JOIN conta c_origem ON t.fk_conta_origem = c_origem.pk_conta JOIN tipo_transacao ti ON ti.pk_tipo_transacao = t.fk_tipo_transacao JOIN cliente cli_origem ON c_origem.pk_conta = cli_origem.fk_conta JOIN login lo_origem ON lo_origem.pk_login = cli_origem.fk_login JOIN pessoa pessoa_origem ON cli_origem.fk_pessoa = pessoa_origem.pk_pessoa JOIN conta c_destino ON t.fk_conta_destino = c_destino.pk_conta JOIN cliente cli_destino ON c_destino.pk_conta = cli_destino.fk_conta JOIN pessoa pessoa_destino ON cli_destino.fk_pessoa = pessoa_destino.pk_pessoa JOIN login lo_destino ON lo_destino.pk_login = cli_destino.fk_login WHERE lo_origem.pk_login=? AND ti.descricao='debito'";
        String query2 = "SELECT pessoa_origem.nome_completo AS nome_origem, pessoa_destino.nome_completo AS nome_destino, t.descricao, t.data, ti.descricao AS tipo, t.valor FROM transacao t JOIN conta c_origem ON t.fk_conta_origem = c_origem.pk_conta\n"
                + "JOIN tipo_transacao ti ON ti.pk_tipo_transacao = t.fk_tipo_transacao\n"
                + "JOIN cliente cli_origem ON c_origem.pk_conta = cli_origem.fk_conta\n"
                + "JOIN login lo_origem ON lo_origem.pk_login = cli_origem.fk_login\n"
                + "JOIN pessoa pessoa_origem ON cli_origem.fk_pessoa = pessoa_origem.pk_pessoa\n"
                + "JOIN conta c_destino ON t.fk_conta_destino = c_destino.pk_conta\n"
                + "JOIN cliente cli_destino ON c_destino.pk_conta = cli_destino.fk_conta\n"
                + "JOIN pessoa pessoa_destino ON cli_destino.fk_pessoa = pessoa_destino.pk_pessoa\n"
                + "JOIN login lo_destino ON lo_destino.pk_login = cli_destino.fk_login\n"
                + "WHERE lo_origem.pk_login=? AND ti.descricao = 'debito'\n"
                + "\n"
                + "UNION\n"
                + "\n"
                + "SELECT pessoa_destino.nome_completo AS nome_origem,\n"
                + "       pessoa_origem.nome_completo AS nome_destino,\n"
                + "       t.descricao,\n"
                + "       t.data,\n"
                + "       ti.descricao AS tipo,\n"
                + "       t.valor\n"
                + "FROM transacao t\n"
                + "JOIN conta c_destino ON t.fk_conta_destino = c_destino.pk_conta\n"
                + "JOIN tipo_transacao ti ON ti.pk_tipo_transacao = t.fk_tipo_transacao\n"
                + "JOIN cliente cli_destino ON c_destino.pk_conta = cli_destino.fk_conta\n"
                + "JOIN login lo_destino ON lo_destino.pk_login = cli_destino.fk_login\n"
                + "JOIN pessoa pessoa_destino ON cli_destino.fk_pessoa = pessoa_destino.pk_pessoa\n"
                + "JOIN conta c_origem ON t.fk_conta_origem = c_origem.pk_conta\n"
                + "JOIN cliente cli_origem ON c_origem.pk_conta = cli_origem.fk_conta\n"
                + "JOIN pessoa pessoa_origem ON cli_origem.fk_pessoa = pessoa_origem.pk_pessoa\n"
                + "JOIN login lo_origem ON lo_origem.pk_login = cli_origem.fk_login\n"
                + "WHERE lo_destino.pk_login=? AND ti.descricao = 'credito';";
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query2);
            ps.setInt(1, pk_login);
            ps.setInt(2, pk_login);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TransacaoView t = new TransacaoView();

                t.setCliente_origem(rs.getString(1));
                t.setCliente_destino(rs.getString(2));
                t.setDescricao(rs.getString(3));
                t.setData(rs.getDate(4));
                t.setTipo(rs.getString(5));
                t.setValor(rs.getDouble(6));

                listaTransacoes.add(t);
            }

            ps.close();
            con.close();

        } catch (SQLException ex) {
        }

        return listaTransacoes;
    }

}
