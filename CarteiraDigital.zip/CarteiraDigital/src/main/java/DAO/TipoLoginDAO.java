/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.TipoLogin;

/**
 *
 * @author valdemar
 */
public class TipoLoginDAO {
    
    public boolean cadastrarTipoLogin(TipoLogin tipo) {
        
        String query_insert = "INSERT INTO tipo_login VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, tipo.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarTipoLogin(int id, String valor){
        String query = "update tipo_login set descricao=? where pk_tipo_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarTipoLogin(int id){
        String query = "delete from tipo_login where pk_tipo_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<TipoLogin> listarTipoLogin() {
        ArrayList<TipoLogin> tipoLogin = new ArrayList<>();
        String query = "SELECT pk_tipo_login, descricao FROM tipo_login";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TipoLogin tipo = new TipoLogin();

                tipo.setPk_tipo_login(rs.getInt(1));
                tipo.setDescricao(rs.getString(2));

                tipoLogin.add(tipo);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return tipoLogin;
    }
    
}
