/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Perfil;
import model.Pessoa;

/**
 *
 * @author valdemar
 */
public class PerfilDAO {
    
    public Perfil getDadosPerfil(int pk_login){
        
        String query = "SELECT p.nome_completo, p.data_nascimento, l.email, conta.iban, con.descricao FROM pessoa p JOIN cliente c ON p.pk_pessoa=c.fk_pessoa JOIN login l ON l.pk_login=c.fk_login JOIN contacto con ON p.pk_pessoa=con.fk_pessoa JOIN conta ON conta.pk_conta=c.fk_conta WHERE l.fk_login=?";

        Perfil perfil = new Perfil();
        ResultSet rs;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_login);

            rs = ps.executeQuery();

            if (rs.next()) {
                perfil.setNome(rs.getString(1));
                perfil.setData_nascimento(rs.getDate(2));
                perfil.setEmail(rs.getString(3));
                perfil.setEndereco(rs.getString(4));
                perfil.setTelefone(Integer.parseInt(rs.getString(5)));

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        return perfil;
        
    }
    
    public void atualizarPerfil(String nomeNovo, Date dataNovo, String telefoneNovo, int pk_pessoa){
        
        Pessoa pessoa = new Pessoa();
        PessoaDAO pessoaDao = new PessoaDAO();
        ContactoDAO contactoDAO = new ContactoDAO();
        
        pessoa.setPk_pessoa(pk_pessoa);
        pessoa.setNome_completo(nomeNovo);
        pessoa.setDataNascimento(dataNovo);
        
        pessoaDao.editarPessoa(pessoa);
        contactoDAO.editarContactoPessoa(pk_pessoa, telefoneNovo);
        
        //JOptionPane.showMessageDialog(null, nomeNovo + " " + dataNovo + " " + telefoneNovo + " " + pk_conta);
    }
    
}
