/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Provincia;

/**
 *
 * @author valdemar
 */
public class ProvinciaDAO {
    
    public boolean cadastrarProvincia(Provincia provincia) {
        
        String query_insert = "INSERT INTO provincia VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, provincia.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarProvincia(int id, String valor){
        String query = "update provincia set descricao=? where pk_provincia=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarProvincia(int id){
        String query = "delete from provincia where pk_provincia=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Provincia> listarProvincia() {
        ArrayList<Provincia> listaProvincia = new ArrayList<>();
        String query = "SELECT pk_provincia, descricao FROM provincia";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Provincia provincia = new Provincia();

                provincia.setPk_provincia(rs.getInt(1));
                provincia.setDescricao(rs.getString(2));

                listaProvincia.add(provincia);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaProvincia;
    }
    
}
