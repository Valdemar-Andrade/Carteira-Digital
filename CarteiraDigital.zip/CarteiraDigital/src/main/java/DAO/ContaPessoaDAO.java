/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ContaPessoa;

/**
 *
 * @author valdemar
 */
public class ContaPessoaDAO {
    
    public ArrayList<ContaPessoa> listarUsuarioContaPessoa(){
        ArrayList<ContaPessoa> contas = new ArrayList<>();
        String query = "select p.nome_completo, con.estado_conta, cli.fk_conta, cli.fk_pessoa from pessoa p join cliente cli on p.pk_pessoa=cli.fk_pessoa join conta con on con.pk_conta=cli.fk_conta";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ContaPessoa pessoa = new ContaPessoa();

                pessoa.setNome(rs.getString(1));
                pessoa.setEstado_conta(rs.getString(2));
                pessoa.setFk_conta(rs.getInt(3));
                pessoa.setFk_pessoa(rs.getInt(4));

                contas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        
        return contas;
    }
    
    public void bloquearConta(int pk_conta, String estado){
        
        ContaDAO conta = new ContaDAO();
        conta.editarEstadoConta(pk_conta, estado);
        
    }
    
    
}
