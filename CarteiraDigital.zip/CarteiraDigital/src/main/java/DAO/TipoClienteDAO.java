/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.TipoCliente;

/**
 *
 * @author valdemar
 */
public class TipoClienteDAO {
    
    public boolean cadastrarTipoCliente(TipoCliente tipoCliente) {
        
        String query_insert = "INSERT INTO tipo_cliente VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, tipoCliente.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarTipoCliente(int id, String valor){
        String query = "update tipo_cliente set descricao=? where pk_tipo_cliente=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarTipoCliente(int id){
        String query = "delete from tipo_cliente where pk_tipo_cliente=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<TipoCliente> listarTipoCliente() {
        ArrayList<TipoCliente> listaTipoCliente = new ArrayList<>();
        String query = "SELECT pk_tipo_cliente, descricao FROM tipo_cliente";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TipoCliente tipoCliente = new TipoCliente();

                tipoCliente.setPk_tipo_cliente(rs.getInt(1));
                tipoCliente.setDescricao(rs.getString(2));

                listaTipoCliente.add(tipoCliente);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaTipoCliente;
    }
    
}
