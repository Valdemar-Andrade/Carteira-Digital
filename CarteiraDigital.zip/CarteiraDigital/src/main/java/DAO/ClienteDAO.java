/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Cliente;

/**
 *
 * @author valdemar
 */
public class ClienteDAO {
    
    public void cadastrarCliente(Cliente cliente) {
        
        String query_insert = "INSERT INTO cliente VALUES (DEFAULT, ?, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setInt(1, cliente.getFk_pessoa());
            ps.setInt(2, cliente.getFk_tipo_cliente());
            ps.setInt(3, cliente.getFk_login());
            ps.setInt(4, cliente.getFk_conta());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public int getUltimoClientePk(){
        String query_insert = "SELECT MAX(pk_cliente) FROM cliente";
        
        int pk_cliente = 0;
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                pk_cliente = rs.getInt(1);
            }
            
        }catch(SQLException ex){}
        
        return pk_cliente;
    }
    
}
