/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Cartao;

/**
 *
 * @author valdemar
 */
public class CartaoDAO {

    public boolean cadastrarCartao(Cartao cartao) {

        String query_insert = "INSERT INTO cartao VALUES (DEFAULT, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, cartao.getDescricao());
            ps.setString(2, cartao.getNumero_cartao());
            ps.setInt(3, cartao.getFk_conta());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }

    public int pegarUltimoCartaoPk() {

        //, descricao, numero_cartao
        String query = "SELECT MAX(pk_cartao) FROM cartao";
        Cartao cartao = new Cartao();

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cartao.setPk_cartao(rs.getInt(1));
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return cartao.getPk_cartao();
    }

    public void editarCartao(int id, String valor) {
        String query = "update cartao set descricao=? where pk_cartao=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public void eliminarCartao(int pk) {
        String query = "delete from cartao where pk_cartao=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<Cartao> listarCartao() {
        ArrayList<Cartao> listaCartao = new ArrayList<>();
        String query = "SELECT pk_cartao, descricao, numero_cartao, fk_conta FROM cartao";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cartao cartao = new Cartao();

                cartao.setPk_cartao(rs.getInt(1));
                cartao.setDescricao(rs.getString(2));
                cartao.setNumero_cartao(rs.getString(3));
                cartao.setFk_conta(rs.getInt(4));

                listaCartao.add(cartao);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaCartao;
    }

}
