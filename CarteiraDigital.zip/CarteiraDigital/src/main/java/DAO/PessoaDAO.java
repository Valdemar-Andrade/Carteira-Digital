/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Pessoa;

/**
 *
 * @author valdemar
 */
public class PessoaDAO {
    
    public void cadastrarPessoa(Pessoa pessoa) {

        String query_insert = "INSERT INTO pessoa VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, pessoa.getNome_completo());
            ps.setString(2, pessoa.getNome_pai());
            ps.setString(3, pessoa.getNome_mae());
            ps.setDate(4, pessoa.getDataNascimento());
            ps.setString(5, pessoa.getNumero_bilhete());
            ps.setInt(6, pessoa.getFk_estado_civil());
            ps.setInt(7, pessoa.getFk_sexo());
            ps.setInt(8, pessoa.getFk_residencia());
            ps.setString(9, pessoa.getNif_empresarial());
            
            ps.execute();

            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void editarPessoa(Pessoa pessoa){
        String query = "update pessoa set nome_completo=?, nome_pai=?, nome_mae=?, data_nascimento=? where pk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, pessoa.getNome_completo());
            ps.setString(2, pessoa.getNome_pai());
            ps.setString(3, pessoa.getNome_mae());
            ps.setDate(4, pessoa.getDataNascimento());
            ps.setInt(5, pessoa.getPk_pessoa());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<Pessoa> listarPessoa() {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        String query = "SELECT pk_pessoa, nome_completo, nome_pai, nome_mae, data_nascimento, numero_bilhete, fk_estado_civil, fk_sexo, fk_residencia, nif_empresarial FROM pessoa";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Pessoa pessoa = new Pessoa();

                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setNome_completo(rs.getString(2));
                pessoa.setNome_pai(rs.getString(3));
                pessoa.setNome_mae(rs.getString(4));
                pessoa.setDataNascimento(rs.getDate(5));
                pessoa.setNumero_bilhete(rs.getString(6));
                pessoa.setFk_estado_civil(rs.getInt(7));
                pessoa.setFk_sexo(rs.getInt(8));
                pessoa.setFk_residencia(rs.getInt(9));
                pessoa.setNif_empresarial(rs.getString(10));

                pessoas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return pessoas;
    }
    
    public int getPkUltimaPessoa(){
        int pk_pessoa = 0;
        
        String query = "SELECT MAX(pk_pessoa) FROM pessoa";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pk_pessoa = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return pk_pessoa;
    }

    //Consultar uma pessoa a partir da chave de um Login
    public Pessoa getPessoaDeLogin(int pk_login) {

        Pessoa pessoa = new Pessoa();
        ResultSet rs;

        //pk_pessoa, fk_usuario, nome
        String query = "SELECT pk_pessoa, nome_completo, nome_pai, nome_mae, data_nascimento, numero_bilhete, fk_estado_civil, fk_sexo, fk_residencia, nif_empresarial FROM pessoa p JOIN cliente c ON p.pk_pessoa=c.fk_pessoa WHERE c.fk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_login);

            rs = ps.executeQuery();

            if (rs.next()) {
                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setNome_completo(rs.getString(2));
                pessoa.setNome_pai(rs.getString(3));
                pessoa.setNome_mae(rs.getString(4));
                pessoa.setDataNascimento(rs.getDate(5));
                pessoa.setNumero_bilhete(rs.getString(6));
                pessoa.setFk_estado_civil(rs.getInt(7));
                pessoa.setFk_sexo(rs.getInt(8));
                pessoa.setFk_residencia(rs.getInt(9));
                pessoa.setNif_empresarial(rs.getString(10));

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        //JOptionPane.showMessageDialog(null, pessoa.toString());
        return pessoa;

    }
    
}
