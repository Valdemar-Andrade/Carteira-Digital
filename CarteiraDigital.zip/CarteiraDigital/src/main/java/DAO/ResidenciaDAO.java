/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Residencia;

/**
 *
 * @author valdemar
 */
public class ResidenciaDAO {
    
    public boolean cadastrarResidencia(Residencia residencia) {
        
        String query_insert = "INSERT INTO residencia VALUES (DEFAULT, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, residencia.getRua());
            ps.setInt(2, residencia.getNumero_casa());
            ps.setInt(3, residencia.getFk_provincia());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarResidencia(int pk_residencia, Residencia residencia){
        String query = "update residencia set rua=?, numero_casa=?, fk_provincia=? where pk_residencia=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, residencia.getRua());
            ps.setInt(2, residencia.getNumero_casa());
            ps.setInt(3, residencia.getFk_provincia());
            ps.setInt(3, pk_residencia);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarResidencia(int id){
        String query = "delete from residencia where pk_residencia=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Residencia> listarResidencia() {
        ArrayList<Residencia> listaResidencia = new ArrayList<>();
        String query = "SELECT pk_residencia, rua, numero_casa, fk_provincia FROM residencia";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Residencia residencia = new Residencia();

                residencia.setPk_residencia(rs.getInt(1));
                residencia.setRua(rs.getString(2));
                residencia.setNumero_casa(rs.getInt(3));
                residencia.setFk_provincia(rs.getInt(4));

                listaResidencia.add(residencia);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaResidencia;
    }
    
    public int getUltimaResidenciaPk() {

        Residencia residencia = new Residencia();
        ResultSet rs;

        //, rua, numero_casa, fk_provincia
        String query = "SELECT MAX(pk_residencia) FROM residencia";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            rs = ps.executeQuery();

            if (rs.next()) {
                residencia.setPk_residencia(rs.getInt(1));

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        return residencia.getPk_residencia();

    }
    
}
