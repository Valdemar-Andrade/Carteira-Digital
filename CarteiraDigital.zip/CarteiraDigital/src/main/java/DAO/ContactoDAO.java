/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Contacto;

/**
 *
 * @author valdemar
 */
public class ContactoDAO {
    
    public boolean cadastrarContacto(Contacto contacto) {
        
        String query_insert = "INSERT INTO contacto VALUES (DEFAULT, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setInt(1, contacto.getDescricao());
            ps.setInt(2, contacto.getFk_pessoa());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarContacto(int id, String valor){
        String query = "update contacto set descricao=? where pk_contacto=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void editarContactoPessoa(int pk_pessoa, String telefoneNovo){
        
        String query = "update contacto set descricao=? where fk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, telefoneNovo);
            ps.setInt(2, pk_pessoa);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        
    }
    
    public void eliminarContacto(int id){
        String query = "delete from contacto where pk_contacto=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public Contacto getContactoPessoa(int pk_pessoa){
        Contacto contacto = new Contacto();

        String query = "SELECT pk_contacto, descricao, fk_pessoa FROM contacto WHERE fk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_pessoa);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                contacto.setPk_contacto(rs.getInt(1));
                contacto.setDescricao(Integer.parseInt(rs.getString(2)));
                contacto.setFk_pessoa(rs.getInt(3));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return contacto;
    }
    
    public ArrayList<Contacto> listarContacto() {
        ArrayList<Contacto> listaContacto = new ArrayList<>();
        String query = "SELECT pk_contacto, descricao, fk_pessoa FROM contacto";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Contacto contacto = new Contacto();

                contacto.setPk_contacto(rs.getInt(1));
                contacto.setDescricao(Integer.parseInt(rs.getString(2)));
                contacto.setFk_pessoa(rs.getInt(3));

                listaContacto.add(contacto);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaContacto;
    }
    
}
