/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Login;
import model.Pessoa;

/**
 *
 * @author valdemar
 */
public class LoginDAO {

    public void cadastrarLogin(Login login) {

        String query_insert = "INSERT INTO login VALUES (DEFAULT, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, login.getEmail());
            ps.setString(2, login.getSenha());
            ps.setInt(3, login.getFk_tipo_login());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<Login> listarLogin() {
        ArrayList<Login> listaLogin = new ArrayList<>();
        String query = "SELECT pk_login, email, senha, fk_tipo_login FROM login";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Login login = new Login();

                login.setPk_login(rs.getInt(1));
                login.setEmail(rs.getString(2));
                login.setSenha(rs.getString(3));
                login.setFk_tipo_login(rs.getInt(4));

                listaLogin.add(login);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaLogin;
    }

    public Login pegarUltimoLogin() {

        Login login = new Login();

        String query = "SELECT max(pk_login) FROM login";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                login.setPk_login(rs.getInt(1));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return login;

    }

    public Login getLogin(int pk_login) {

        Login login = new Login();

        String query = "SELECT pk_login, email, senha, fk_tipo_login FROM login WHERE pk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_login);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                login.setPk_login(rs.getInt(1));
                login.setEmail(rs.getString(2));
                login.setSenha(rs.getString(3));
                login.setFk_tipo_login(rs.getInt(4));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return login;
    }
    
    public Login verificarLogin(String email, String senha) {
        
        String query = "SELECT pk_login, email, senha, fk_tipo_login FROM login WHERE email=? AND senha=?";

        ResultSet rs;
        Login login = new Login();

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, email);
            ps.setString(2, senha);

            rs = ps.executeQuery();

            if (rs.next()) {
                login.setPk_login(rs.getInt(1));
                login.setEmail(rs.getString(2));
                login.setSenha(rs.getString(3));
                login.setFk_tipo_login(rs.getInt(4));

                rs.close();
                ps.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        return login;
    }

    public String tipoLogin(int pk_tipo_login) {
        String tipoLogin = "none";
        String query;

        query = "SELECT descricao FROM tipo_login WHERE pk_tipo_login=?";

        Connection con = Conexao.abrirConexao();
        ResultSet rs;

        try {

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_tipo_login);

            rs = ps.executeQuery();

            if (rs.next()) {
                tipoLogin = rs.getString(1);

                ps.close();
                rs.close();
            }

        } catch (SQLException ex) {
            System.out.println("");
        }
        
        return tipoLogin;
    }

    public boolean verificarSenhaValidarTransferencia(String senha, int pk_login) {

        String query = "SELECT pk_login, email, senha, fk_tipo_login FROM login WHERE pk_login=?";
        Login login = new Login();

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_login);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                login.setPk_login(rs.getInt(1));
                login.setEmail(rs.getString(2));
                login.setSenha(rs.getString(3));
                login.setFk_tipo_login(rs.getInt(4));
            }
            
            return senha.equals(login.getSenha());

        } catch (SQLException | NullPointerException ex) {
        }

        return false;
    }
    
    public String getNomePessoaByIBAN(String iban){
        
        String query = "select pe.nome from carteira_cartao_moeda ccm join carteira ca on ca.pk_carteira = ccm.fk_carteira join cartao c on c.pk_cartao = ccm.fk_cartao join conta co on co.pk_conta = ca.fk_conta join pessoa pe on pe.fk_conta = co.pk_conta where c.numero_cartao=?";
        Pessoa pessoa = new Pessoa();
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, iban);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pessoa.setNome_completo(rs.getString(1));
            }

        } catch (SQLException | NullPointerException ex) {
        }
        
        //JOptionPane.showMessageDialog(null, "IBAN recebido: " + iban + " Nome encontrado: " + pessoa.getNome());
        
        return pessoa.getNome_completo();
        
    }

}
