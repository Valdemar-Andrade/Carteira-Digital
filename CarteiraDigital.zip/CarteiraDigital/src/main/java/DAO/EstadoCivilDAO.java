/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.EstadoCivil;

/**
 *
 * @author valdemar
 */
public class EstadoCivilDAO {
    
    public boolean cadastrarEstadoCivil(EstadoCivil estadoCivil) {

        String query_insert = "INSERT INTO estado_civil VALUES (DEFAULT, ?);";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, estadoCivil.getDescricao());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarEstadoCivil(int id, String valor){
        String query = "update estado_civil set descricao=? where pk_estado_civil=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarEstadoCivil(int id){
        String query = "delete from estado_civil where pk_estado_civil=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<EstadoCivil> listarEstadoCivil() {
        ArrayList<EstadoCivil> estadoCivils = new ArrayList<>();
        String query = "SELECT pk_estado_civil, descricao FROM estado_civil";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EstadoCivil estadoCivil = new EstadoCivil();
                
                estadoCivil.setPk_estado_civil(rs.getInt(1));
                estadoCivil.setDescricao(rs.getString(2));

                estadoCivils.add(estadoCivil);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return estadoCivils;
    }
    
}
