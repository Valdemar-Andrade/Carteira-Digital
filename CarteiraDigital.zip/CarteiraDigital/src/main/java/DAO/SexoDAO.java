/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Sexo;

/**
 *
 * @author valdemar
 */
public class SexoDAO {
    
    public boolean cadastrarSexo(Sexo sexo) {
        
        String query_insert = "INSERT INTO sexo VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, sexo.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarSexo(int id, String valor){
        String query = "update sexo set descricao=? where pk_sexo=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarSexo(int id){
        String query = "delete from sexo where pk_sexo=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Sexo> listarSexo() {
        ArrayList<Sexo> listaSexo = new ArrayList<>();
        String query = "SELECT pk_sexo, descricao FROM sexo";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Sexo sexo = new Sexo();

                sexo.setPk_sexo(rs.getInt(1));
                sexo.setDescricao(rs.getString(2));

                listaSexo.add(sexo);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaSexo;
    }
    
}
