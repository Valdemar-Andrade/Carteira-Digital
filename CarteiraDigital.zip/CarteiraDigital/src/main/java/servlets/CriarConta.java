/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import DAO.ClienteDAO;
import DAO.ContaDAO;
import DAO.LoginDAO;
import DAO.ContactoDAO;
import DAO.PessoaDAO;
import DAO.ResidenciaDAO;
import Encriptador.EncriptadorRSA;
import java.io.IOException;
import java.sql.Date;
import java.util.Base64;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import model.Cliente;
import model.Conta;
import model.Contacto;
import model.Login;
import model.Pessoa;
import model.Residencia;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "CriarConta", urlPatterns = {"/CriarConta"})
public class CriarConta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getServletPath().equals("/CriarConta")) {
            //JOptionPane.showMessageDialog(null, "Entrou criar conta");
            
            String nome_completo = request.getParameter("nome_completo").trim();
            String nome_pai = request.getParameter("nome_pai").trim();
            String nome_mae = request.getParameter("nome_mae").trim();
            String email = request.getParameter("email").trim();
            String senha1 = request.getParameter("senha1").trim();
            String senha2 = request.getParameter("senha2").trim();
            String rua = request.getParameter("rua").trim();
            String numero_bilhete = request.getParameter("numero_bi").trim();
            String nif = "";
            
            Date dataNascimento = null;
            int telefone = 0;
            int sexo = 0;
            int estado_civil = 0;
            int numero_casa = 0;
            int provincia = 0;
            int tipo_login = 0;
            int moeda = 1;
            //int tipo_cliente = 0;
            String tipo_cliente = request.getParameter("tipo_cliente");
            //JOptionPane.showMessageDialog(null, "Tipo Cliente get: " + tipo_cliente);
            
            
            try {

                dataNascimento = Date.valueOf(request.getParameter("data_nascimento").trim());
                telefone = Integer.parseInt(request.getParameter("telefone").trim());
                sexo = Integer.parseInt(request.getParameter("sexo").trim());
                estado_civil = Integer.parseInt(request.getParameter("estado_civil"));
                numero_casa = Integer.parseInt(request.getParameter("numero_casa"));
                provincia = Integer.parseInt(request.getParameter("provincia"));
                tipo_login = Integer.parseInt(request.getParameter("tipo_login"));
                //tipo_cliente = Integer.parseInt(request.getParameter("tipo_cliente"));
                nif = request.getParameter("nif_empresarial").trim();
                //moeda = Integer.parseInt(request.getParameter("moeda"));

            } catch (NumberFormatException | NullPointerException ex) {
                System.out.println("Erro na convercao de alguns dados do formulario Criar Conta/Login " + ex.getLocalizedMessage());
            }

            //JOptionPane.showMessageDialog(null, "Dados Recebidos: " + nome + " " + email + " " + sexo + " " + dataNascimento + " " + telefone + " " + senha1 + " " + senha2);
            //Validacao dos campos
            if (validarCampos(nome_completo, nome_pai, nome_mae, email, sexo, estado_civil, numero_casa, numero_bilhete, rua, provincia, dataNascimento, telefone, senha1, senha2, tipo_login)) {

                //Cadastro do Login
                Login login = new Login();
                login.setEmail(email);
                login.setSenha(senha1);
                login.setFk_tipo_login(tipo_login);

                LoginDAO loginDao = new LoginDAO();
                loginDao.cadastrarLogin(login);

                //A chave do Login criado
                int fk_login = loginDao.pegarUltimoLogin().getPk_login();
                
                //JOptionPane.showMessageDialog(null, "Chave Login: " + fk_login);
                
                //Cadastro da Residencia
                Residencia residencia = new Residencia();
                residencia.setRua(rua);
                residencia.setNumero_casa(numero_casa);
                residencia.setFk_provincia(provincia);
                
                //JOptionPane.showMessageDialog(null, residencia.toString());
                
                ResidenciaDAO residenciaDao = new ResidenciaDAO();
                residenciaDao.cadastrarResidencia(residencia);
                
                //A chave da residencia criada
                int fk_residencia = residenciaDao.getUltimaResidenciaPk();
                
                //JOptionPane.showMessageDialog(null, "Chave Residencia: " + fk_residencia);
                
                //Cadastro da pessoa
                Pessoa pessoa = new Pessoa();
                pessoa.setNome_completo(nome_completo);
                pessoa.setNome_pai(nome_pai);
                pessoa.setNome_mae(nome_mae);
                pessoa.setDataNascimento(dataNascimento);
                pessoa.setFk_estado_civil(estado_civil);
                pessoa.setFk_sexo(sexo);
                pessoa.setFk_residencia(fk_residencia);
                pessoa.setNumero_bilhete(numero_bilhete);
                pessoa.setNif_empresarial(nif);
                
                PessoaDAO pessoaDao = new PessoaDAO();
                pessoaDao.cadastrarPessoa(pessoa);

                //A chave da pessoa criada
                int fk_pessoa = pessoaDao.getPkUltimaPessoa();
                
                //JOptionPane.showMessageDialog(null, "Chave Pessoa: " + fk_pessoa);
                
                //Cadastro do contacto
                Contacto contacto = new Contacto();
                contacto.setDescricao(telefone);
                contacto.setFk_pessoa(fk_pessoa);

                ContactoDAO contactoDao = new ContactoDAO();
                contactoDao.cadastrarContacto(contacto);
                
                //Criar a Conta
                Conta conta = new Conta();
                
                //Gerar o numero da Conta
                int numeroConta = new Random().nextInt(90000) + 10000;
                int iban = new Random().nextInt(9000) + 1000;
                
                conta.setNumero_conta(numeroConta + "");
                conta.setIban(numeroConta + "" + iban);
                conta.setSaldo_contabilistico(500);
                conta.setSaldo_disponivel(500);
                conta.setEstado_conta("aberta");
                //
                EncriptadorRSA encriptador = new EncriptadorRSA();
                
                String chave_privada_armazenar = Base64.getEncoder().encodeToString(encriptador.getChavePrivada().getEncoded());
                String chave_publica_armazenar = Base64.getEncoder().encodeToString(encriptador.getChavePublica().getEncoded());
                
                System.out.println("Chave privada String: " + chave_privada_armazenar + "\nChave publica String: " + chave_publica_armazenar);
                
                conta.setChave_privada(chave_privada_armazenar);
                conta.setChave_publica(chave_publica_armazenar);
                conta.setFk_moeda(moeda);

                ContaDAO contaDao = new ContaDAO();
                contaDao.criarConta(conta);
                
                //Pegar a chave da ultima Conta criada
                int fk_conta = contaDao.getUltimaContaPk();
                
                //JOptionPane.showMessageDialog(null, "Chave Conta: " + fk_conta);
                
                //Cadastro cliente
                Cliente cliente = new Cliente();
                cliente.setFk_pessoa(fk_pessoa);
                cliente.setFk_tipo_cliente(1);
                //cliente.setFk_tipo_cliente(Integer.parseInt(request.getParameter("tipo_cliente")));
                cliente.setFk_login(fk_login);
                cliente.setFk_conta(fk_conta);
                
                ClienteDAO clienteDao = new ClienteDAO();
                clienteDao.cadastrarCliente(cliente);
                
                
                //JOptionPane.showMessageDialog(null, "Cliente: fk_pess: "+ cliente.getFk_pessoa() + " fk_tipo: " + cliente.getFk_tipo_cliente() + " fk_login: " + cliente.getFk_login()+ " fk_conta: " + cliente.getFk_conta() +"\nChave Cliente: " + clienteDao.getUltimoClientePk());

                response.sendRedirect("index.jsp");

            } else {
                response.sendRedirect("error.jsp?erro=Preencha os Campos Corretamente");
            }
        }

    }

    public CriarConta() {
    }

    private boolean validarCampos(String nome, String nome_pai, String nome_mae, String email, int sexo, int estado_civil, int numero_casa, String numero_bilhete, String rua, int provincia, Date dataNascimento, int telefone, String senha1, String senha2, int tipo_login) {
        return !nome.isEmpty() && !nome_pai.isEmpty() && !nome_mae.isEmpty() && !email.isEmpty() && sexo > 0 && estado_civil > 0 && numero_casa > 0 && provincia > 0 && dataNascimento != null && telefone > 0 && !numero_bilhete.isEmpty() && !rua.isEmpty() && !senha1.isEmpty() && !senha2.isEmpty() && senha1.equals(senha2) && tipo_login > 0;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
