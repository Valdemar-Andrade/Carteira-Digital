/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import DAO.ContaDAO;
import DAO.LoginDAO;
import JMS.Mensagem;
import JMS.Messenger;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "RealizarTransferencia", urlPatterns = {"/RealizarTransferencia"})
public class RealizarTransferencia extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getServletPath().equals("/RealizarTransferencia")) {
            
            String senha = request.getParameter("senha").trim();
            String iban_beneficiario = request.getParameter("iban_beneficiario").trim();
            String descricao = request.getParameter("descricao").trim();

            String conta_origem;
            double valor;

            try {

                int loginID = Integer.parseInt(request.getParameter("loginID"));
                valor = Double.parseDouble(request.getParameter("valor").trim());
                conta_origem = new ContaDAO().getContaNumero(Integer.parseInt(request.getParameter("loginID")));

                if (validar(iban_beneficiario, descricao, valor, senha, loginID)) {

                    //Preparar para usar o jms
                    Messenger ms = new Messenger();
                    ms.inscrever();
                    
                    //Preparar a msg com os dados
                    Mensagem.conta_origem = conta_origem;
                    Mensagem.descricao = descricao;
                    Mensagem.iban_beneficiario = iban_beneficiario;
                    Mensagem.valor = valor;
                    
                    //Pedir a chave publica para criptografar a mensagem
                    ms.enviarMensagemPedidoChavePublica(iban_beneficiario, "Pedido da Chave Publica");
                    
                    //Enviar a mensagem com os dados da transferencia para o Sistema de Validacao
                    //ms.enviarMensagem(iban_beneficiario, descricao, valor, conta_origem);
                    
                    response.sendRedirect("dashboard.jsp?senha=true");
                } else {
                    //Senha incorreta
                    response.sendRedirect("debito.jsp?senha=false");
                }

            } catch (NullPointerException | NumberFormatException ex) {
                response.sendRedirect("dashboard.jsp");
            }

        }

    }

    private boolean validar(String endereco, String descricao, double valor, String senha, int pk_conta) {

        return !endereco.isEmpty() && !descricao.isEmpty() && valor > 0 && new LoginDAO().verificarSenhaValidarTransferencia(senha, pk_conta);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
