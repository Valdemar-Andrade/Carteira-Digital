/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import DAO.MoedaDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Moeda;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "CadastrarMoeda", urlPatterns = {"/CadastrarMoeda"})
public class CadastrarMoeda extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        if (request.getServletPath().equals("/CadastrarMoeda")) {
            String acao = request.getParameter("acao").trim();

            //Cadastrar moeda
            if (acao.equalsIgnoreCase("cadastrar")) {
                String valor = request.getParameter("moeda").trim();

                if (!valor.isEmpty()) {
                    Moeda moeda = new Moeda();
                    moeda.setDescricao(valor);

                    MoedaDAO dao = new MoedaDAO();
                    dao.cadastrarMoeda(moeda);
                }
                
                response.sendRedirect("gerir.jsp");
            }

            //Editar moeda
            if (acao.equalsIgnoreCase("editar")) {
                int id = Integer.parseInt(request.getParameter("id"));
                String novoValor = request.getParameter("novo-valor").trim();

                if (!novoValor.isEmpty()) {
                    MoedaDAO dao = new MoedaDAO();
                    dao.editarMoeda(id, novoValor);
                }
                
                response.sendRedirect("gerir.jsp");
            }

            //Eliminar moeda
            if (acao.equalsIgnoreCase("eliminar")) {
                int id = Integer.parseInt(request.getParameter("id"));

                MoedaDAO dao = new MoedaDAO();
                dao.eliminarMoeda(id);
                
                response.sendRedirect("gerir.jsp");
            }

        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
