/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class ContaPessoa {
    
    private int pk_conta_pessoa, fk_conta, fk_pessoa;
    private String nome, estado_conta;

    public ContaPessoa() {
    }

    public ContaPessoa(int pk_conta_pessoa, int fk_conta, int fk_pessoa, String nome, String estado_conta) {
        this.pk_conta_pessoa = pk_conta_pessoa;
        this.fk_conta = fk_conta;
        this.fk_pessoa = fk_pessoa;
        this.nome = nome;
        this.estado_conta = estado_conta;
    }

    public int getPk_conta_pessoa() {
        return pk_conta_pessoa;
    }

    public void setPk_conta_pessoa(int pk_conta_pessoa) {
        this.pk_conta_pessoa = pk_conta_pessoa;
    }

    public int getFk_conta() {
        return fk_conta;
    }

    public void setFk_conta(int fk_conta) {
        this.fk_conta = fk_conta;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado_conta() {
        return estado_conta;
    }

    public void setEstado_conta(String estado_conta) {
        this.estado_conta = estado_conta;
    }
    
    
}
