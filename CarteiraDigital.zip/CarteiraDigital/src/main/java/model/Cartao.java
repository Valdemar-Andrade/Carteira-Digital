/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Cartao {
    
    private int pk_cartao, fk_conta;
    private String descricao, numero_cartao;

    public Cartao() {
    }

    public Cartao(int pk_cartao, String numero_cartao, String descricao, int fk_conta) {
        this.pk_cartao = pk_cartao;
        this.numero_cartao = numero_cartao;
        this.descricao = descricao;
        this.fk_conta = fk_conta;
    }

    public int getPk_cartao() {
        return pk_cartao;
    }

    public void setPk_cartao(int pk_cartao) {
        this.pk_cartao = pk_cartao;
    }

    public String getNumero_cartao() {
        return numero_cartao;
    }

    public void setNumero_cartao(String numero_cartao) {
        this.numero_cartao = numero_cartao;
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getFk_conta() {
        return fk_conta;
    }

    public void setFk_conta(int fk_conta) {
        this.fk_conta = fk_conta;
    }
    
    
    
}
