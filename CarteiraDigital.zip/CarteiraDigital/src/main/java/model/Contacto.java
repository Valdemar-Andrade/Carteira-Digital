/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Contacto {
    
    private int pk_contacto, fk_pessoa;
    private int descricao;

    public Contacto() {
    }

    public Contacto(int pk_contacto, int fk_pessoa, int descricao) {
        this.pk_contacto = pk_contacto;
        this.fk_pessoa = fk_pessoa;
        this.descricao = descricao;
    }

    public int getPk_contacto() {
        return pk_contacto;
    }

    public void setPk_contacto(int pk_contacto) {
        this.pk_contacto = pk_contacto;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public int getDescricao() {
        return descricao;
    }

    public void setDescricao(int descricao) {
        this.descricao = descricao;
    }
    
    
    
}
