/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author valdemar
 */
public class TransacaoView {
    
    private int pk_transacao;
    private String cliente_origem, cliente_destino, descricao, tipo;
    private Date data;
    private double valor;

    public TransacaoView() {
    }

    public TransacaoView(int pk_transacao, String cliente_origem, String cliente_destino, String descricao, String tipo, Date data, double valor) {
        this.pk_transacao = pk_transacao;
        this.cliente_origem = cliente_origem;
        this.cliente_destino = cliente_destino;
        this.descricao = descricao;
        this.tipo = tipo;
        this.data = data;
        this.valor = valor;
    }

    public int getPk_transacao() {
        return pk_transacao;
    }

    public void setPk_transacao(int pk_transacao) {
        this.pk_transacao = pk_transacao;
    }

    public String getCliente_origem() {
        return cliente_origem;
    }

    public void setCliente_origem(String cliente_origem) {
        this.cliente_origem = cliente_origem;
    }

    public String getCliente_destino() {
        return cliente_destino;
    }

    public void setCliente_destino(String cliente_destino) {
        this.cliente_destino = cliente_destino;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    
    
}
