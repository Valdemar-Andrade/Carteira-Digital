/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class TipoCliente {
    
    private int pk_tipo_cliente;
    private String descricao;

    public TipoCliente() {
    }

    public TipoCliente(int pk_tipo_cliente, String descricao) {
        this.pk_tipo_cliente = pk_tipo_cliente;
        this.descricao = descricao;
    }

    public int getPk_tipo_cliente() {
        return pk_tipo_cliente;
    }

    public void setPk_tipo_cliente(int pk_tipo_cliente) {
        this.pk_tipo_cliente = pk_tipo_cliente;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
