/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Moeda {
    
    private int pk_moeda;
    private String descricao;

    public Moeda() {
    }

    public Moeda(int pk_moeda, String descricao) {
        this.pk_moeda = pk_moeda;
        this.descricao = descricao;
    }

    public int getPk_moeda() {
        return pk_moeda;
    }

    public void setPk_moeda(int pk_moeda) {
        this.pk_moeda = pk_moeda;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
}
