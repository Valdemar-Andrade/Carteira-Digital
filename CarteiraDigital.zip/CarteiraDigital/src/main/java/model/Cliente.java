/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Cliente {
    
    private int pk_cliente, fk_pessoa, fk_tipo_cliente, fk_login, fk_conta;

    public Cliente() {
    }

    public Cliente(int pk_cliente, int fk_pessoa, int fk_tipo_cliente, int fk_login, int fk_conta) {
        this.pk_cliente = pk_cliente;
        this.fk_pessoa = fk_pessoa;
        this.fk_tipo_cliente = fk_tipo_cliente;
        this.fk_login = fk_login;
        this.fk_conta = fk_conta;
    }

    public int getPk_cliente() {
        return pk_cliente;
    }

    public void setPk_cliente(int pk_cliente) {
        this.pk_cliente = pk_cliente;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public int getFk_tipo_cliente() {
        return fk_tipo_cliente;
    }

    public void setFk_tipo_cliente(int fk_tipo_cliente) {
        this.fk_tipo_cliente = fk_tipo_cliente;
    }

    public int getFk_login() {
        return fk_login;
    }

    public void setFk_login(int fk_login) {
        this.fk_login = fk_login;
    }

    public int getFk_conta() {
        return fk_conta;
    }

    public void setFk_conta(int fk_conta) {
        this.fk_conta = fk_conta;
    }
    
    

}
