/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class TipoLogin {
    
    private int pk_tipo_login;
    private String descricao;

    public TipoLogin() {
    }

    public TipoLogin(int pk_tipo_login, String descricao) {
        this.pk_tipo_login = pk_tipo_login;
        this.descricao = descricao;
    }

    public int getPk_tipo_login() {
        return pk_tipo_login;
    }

    public void setPk_tipo_login(int pk_tipo_login) {
        this.pk_tipo_login = pk_tipo_login;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
