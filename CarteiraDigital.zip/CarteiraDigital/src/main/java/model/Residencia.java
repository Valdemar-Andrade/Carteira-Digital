/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Residencia {
    
    private int pk_residencia, numero_casa, fk_provincia;
    private String rua;

    public Residencia() {
    }

    public Residencia(int pk_residencia, int numero_casa, int fk_provincia, String rua) {
        this.pk_residencia = pk_residencia;
        this.numero_casa = numero_casa;
        this.fk_provincia = fk_provincia;
        this.rua = rua;
    }

    public int getPk_residencia() {
        return pk_residencia;
    }

    public void setPk_residencia(int pk_residencia) {
        this.pk_residencia = pk_residencia;
    }

    public int getNumero_casa() {
        return numero_casa;
    }

    public void setNumero_casa(int numero_casa) {
        this.numero_casa = numero_casa;
    }

    public int getFk_provincia() {
        return fk_provincia;
    }

    public void setFk_provincia(int fk_provincia) {
        this.fk_provincia = fk_provincia;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }
    
    @Override
    public String toString(){
        return getPk_residencia() + " " + getRua() + " " + getNumero_casa() + " " + getFk_provincia();
    }
    
}
