/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Conta {
    
    private int pk_conta, fk_moeda;
    private String numero_conta, iban, estado_conta, chave_privada, chave_publica;
    private double saldo_contabilistico, saldo_disponivel;
    

    public Conta() {
    }

    public Conta(int pk_conta, int fk_moeda, String numero_conta, String iban, String estado_conta, String chave_privada, String chave_publica, double saldo_contabilistico, double saldo_disponivel) {
        this.pk_conta = pk_conta;
        this.fk_moeda = fk_moeda;
        this.numero_conta = numero_conta;
        this.iban = iban;
        this.estado_conta = estado_conta;
        this.chave_privada = chave_privada;
        this.chave_publica = chave_publica;
        this.saldo_contabilistico = saldo_contabilistico;
        this.saldo_disponivel = saldo_disponivel;
    }

    public int getPk_conta() {
        return pk_conta;
    }

    public void setPk_conta(int pk_conta) {
        this.pk_conta = pk_conta;
    }

    public int getFk_moeda() {
        return fk_moeda;
    }

    public void setFk_moeda(int fk_moeda) {
        this.fk_moeda = fk_moeda;
    }

    public String getNumero_conta() {
        return numero_conta;
    }

    public void setNumero_conta(String numero_conta) {
        this.numero_conta = numero_conta;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getEstado_conta() {
        return estado_conta;
    }

    public void setEstado_conta(String estado_conta) {
        this.estado_conta = estado_conta;
    }

    public String getChave_privada() {
        return chave_privada;
    }

    public void setChave_privada(String chave_privada) {
        this.chave_privada = chave_privada;
    }

    public String getChave_publica() {
        return chave_publica;
    }

    public void setChave_publica(String chave_publica) {
        this.chave_publica = chave_publica;
    }

    public double getSaldo_contabilistico() {
        return saldo_contabilistico;
    }

    public void setSaldo_contabilistico(double saldo_contabilistico) {
        this.saldo_contabilistico = saldo_contabilistico;
    }

    public double getSaldo_disponivel() {
        return saldo_disponivel;
    }

    public void setSaldo_disponivel(double saldo_disponivel) {
        this.saldo_disponivel = saldo_disponivel;
    }

    @Override
    public String toString() {
        return "Conta{" + "pk_conta=" + pk_conta + ", fk_moeda=" + fk_moeda + ", numero_conta=" + numero_conta + ", iban=" + iban + ", estado_conta=" + estado_conta + ", chave_privada=" + chave_privada + ", chave_publica=" + chave_publica + ", saldo_contabilistico=" + saldo_contabilistico + ", saldo_disponivel=" + saldo_disponivel + '}';
    }
    
    
}
