/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author valdemar
 */
public class Pessoa {
    
    private int pk_pessoa, fk_sexo, fk_residencia, fk_estado_civil;
    private String nome_completo, nome_pai, nome_mae, numero_bilhete, nif_empresarial;
    private Date dataNascimento;

    public Pessoa() {
    }

    public Pessoa(int pk_pessoa, int fk_sexo, int fk_residencia, int fk_estado_civil, String nome_completo, String nome_pai, String nome_mae, Date dataNascimento, String estado_civil, String numero_bilhete, String nif_empresarial) {
        this.pk_pessoa = pk_pessoa;
        this.fk_sexo = fk_sexo;
        this.fk_residencia = fk_residencia;
        this.nome_completo = nome_completo;
        this.dataNascimento = dataNascimento;
        this.fk_estado_civil = fk_estado_civil;
        this.numero_bilhete = numero_bilhete;
        this.nome_pai = nome_pai;
        this.nome_mae = nome_mae;
        this.nif_empresarial = nif_empresarial;
    }

    public int getPk_pessoa() {
        return pk_pessoa;
    }

    public void setPk_pessoa(int pk_pessoa) {
        this.pk_pessoa = pk_pessoa;
    }

    public int getFk_sexo() {
        return fk_sexo;
    }

    public void setFk_sexo(int fk_sexo) {
        this.fk_sexo = fk_sexo;
    }

    public int getFk_residencia() {
        return fk_residencia;
    }

    public int getFk_estado_civil() {
        return fk_estado_civil;
    }

    public void setFk_estado_civil(int fk_estado_civil) {
        this.fk_estado_civil = fk_estado_civil;
    }

    public void setFk_residencia(int fk_residencia) {
        this.fk_residencia = fk_residencia;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getNumero_bilhete() {
        return numero_bilhete;
    }

    public void setNumero_bilhete(String numero_bilhete) {
        this.numero_bilhete = numero_bilhete;
    }

    public String getNome_completo() {
        return nome_completo;
    }

    public void setNome_completo(String nome_completo) {
        this.nome_completo = nome_completo;
    }

    public String getNome_pai() {
        return nome_pai;
    }

    public void setNome_pai(String nome_pai) {
        this.nome_pai = nome_pai;
    }

    public String getNome_mae() {
        return nome_mae;
    }

    public void setNome_mae(String nome_mae) {
        this.nome_mae = nome_mae;
    }

    public String getNif_empresarial() {
        return nif_empresarial;
    }

    public void setNif_empresarial(String nif_empresarial) {
        this.nif_empresarial = nif_empresarial;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "pk_pessoa=" + pk_pessoa + ", fk_sexo=" + fk_sexo + ", fk_residencia=" + fk_residencia + ", fk_estado_civil=" + fk_estado_civil + ", nome_completo=" + nome_completo + ", nome_pai=" + nome_pai + ", nome_mae=" + nome_mae + ", numero_bilhete=" + numero_bilhete + ", nif_empresarial=" + nif_empresarial + ", dataNascimento=" + dataNascimento + '}';
    }
    
}
