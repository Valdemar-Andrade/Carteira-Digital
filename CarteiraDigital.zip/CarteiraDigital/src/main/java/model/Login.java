/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Login {
    
    private int pk_login, fk_tipo_login;
    private String email, senha;

    public Login() {
    }

    public Login(int pk_login, int fk_tipo_login, String email, String senha) {
        this.pk_login = pk_login;
        this.fk_tipo_login = fk_tipo_login;
        this.email = email;
        this.senha = senha;
    }

    public int getPk_login() {
        return pk_login;
    }

    public void setPk_login(int pk_login) {
        this.pk_login = pk_login;
    }

    public int getFk_tipo_login() {
        return fk_tipo_login;
    }

    public void setFk_tipo_login(int fk_tipo_login) {
        this.fk_tipo_login = fk_tipo_login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
    
}
