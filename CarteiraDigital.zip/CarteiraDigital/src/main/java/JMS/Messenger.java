/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JMS;

import DAO.ContaDAO;
import Encriptador.EncriptadorRSA;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import org.apache.activemq.ActiveMQConnectionFactory;

/**
 *
 * @author valdemar
 */
public class Messenger {

    private final String nomeTopico = "topico";

    public void inscrever() {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageConsumer consumidor = session.createConsumer(topico);

            consumidor.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(Message mensagem) {
                    try {
                        if (mensagem instanceof TextMessage) {
                            TextMessage textMessage = (TextMessage) mensagem;
                            //App Principal

                            if (textMessage.getBooleanProperty("chave_publica")) {
                                try {
                                    byte[] chavePublicaBytes = Base64.getDecoder().decode(textMessage.getText());
                                    PublicKey chavePublica = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(chavePublicaBytes));

                                    enviarMensagemCriptografada(Mensagem.iban_beneficiario, Mensagem.descricao, Mensagem.valor, Mensagem.conta_origem, chavePublica);
                                    //System.out.println("\nMensagem: " + Mensagem.descricao);
                                    //System.out.println("\nChave pública recebida App: " + chavePublica);
                                } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
                                    System.out.println("Erro... " + ex);
                                }
                            }

                            //Verifica a Confirmacao recebida do Sistema de Validacao
                            if (textMessage.getBooleanProperty("confirmacaoID") == true && textMessage.getText().equalsIgnoreCase("Sucesso")) {
                                //A transacao foi realizada com Sucesso!
                                System.out.println("\nTransacao realizada com sucesso!");

                            } else if (textMessage.getText().equalsIgnoreCase("Falhou")) {
                                System.out.println("\nO Sistema de Validacao Recusou a Transacao!");
                            } else {
                                System.out.println("\nAguardando Sistema de Validacao!");
                            }
                        }
                    } catch (JMSException e) {
                        e.printStackTrace();
                    }
                }
            });

            //System.out.println("No " + id + " inscrito no tópico: " + nomeTopico);
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public void enviarMensagem(String iban_beneficiario, String descricao, double valor, String conta_origem) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);

            //Elaborar a mensagem com dados da Transacao e enviar para o Sistema de Validacao
            TextMessage msg = session.createTextMessage();
            msg.setText(descricao);
            msg.setStringProperty("iban_beneficiario", iban_beneficiario);
            msg.setDoubleProperty("valor", valor);
            msg.setStringProperty("conta_origem", conta_origem);
            msg.setBooleanProperty("transacao", true);

            produtor.send(msg);

        } catch (JMSException e) {
        }
    }

    public void enviarMensagemCriptografada(String iban_beneficiario, String descricao, double valor, String conta_origem, PublicKey chave_publica) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);

            //Elaborar a mensagem com dados da Transacao e enviar para o Sistema de Validacao
            TextMessage msg = session.createTextMessage();
            msg.setText(descricao);

            //Criptografar a msg
            EncriptadorRSA encriptador = new EncriptadorRSA(chave_publica);

            //System.out.println("Mensagem antes: " + mensagemEncriptar);
            encriptador.setChavePublica(chave_publica);

            //String conta_origem_cripto = codificar(encriptador, conta_origem);
            msg.setStringProperty("iban_beneficiario", iban_beneficiario);
            //msg.setStringProperty("valor", codificar(encriptador, valor + ""));
            String v = valor + "";
            String c = conta_origem + "";

            byte[] valorEncriptada = encriptador.encriptar(v.getBytes(), chave_publica);
            String encoded = Base64.getEncoder().encodeToString(valorEncriptada);
            //String encoded = bytesToHex(valorEncriptada);

            byte[] contaEncriptada = encriptador.encriptar(c.getBytes(), chave_publica);
            String encoded2 = Base64.getEncoder().encodeToString(contaEncriptada);
            //String encoded2 = bytesToHex(contaEncriptada);

            //Encriptar os dados essenciais antes de enviar
            msg.setStringProperty("valor", encoded);
            msg.setStringProperty("conta_origem", encoded2);
            msg.setBooleanProperty("transacao", true);

            //System.out.println("\nConta Origem criptografado: " + conta_origem_cripto);
            //byte[] encriptada = encriptador.encriptar(mensagem.getBytes());
            //String encoded = Base64.getEncoder().encodeToString(encriptada);
            produtor.send(msg);

        } catch (JMSException e) {
        }
    }

    public String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02X", b));
        }
        return result.toString();
    }

    /*
    private String codificar(EncriptadorRSA encriptador, String mensagem) {
        byte[] encriptada = encriptador.encriptarRepartido(mensagem.getBytes());
        String encoded = Base64.getEncoder().encodeToString(encriptada);

        return encoded;
    }*/
    public void enviarMensagemPedidoChavePublica(String iban_beneficiario, String descricao) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);

            //Elaborar a mensagem para pedido da chave publica
            TextMessage msg = session.createTextMessage();
            msg.setText(descricao);
            msg.setStringProperty("iban_beneficiario", iban_beneficiario);
            msg.setBooleanProperty("pedidoChavePublica", true);

            produtor.send(msg);

        } catch (JMSException e) {
        }
    }

    public String getNomeTopico() {
        return nomeTopico;
    }

}
