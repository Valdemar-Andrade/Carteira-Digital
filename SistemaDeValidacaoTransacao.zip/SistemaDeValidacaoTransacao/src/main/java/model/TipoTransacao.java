/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class TipoTransacao {
    
    private int pk_tipo_transacao;
    private String descricao;

    public TipoTransacao() {
    }

    public TipoTransacao(int pk_tipo_transacao, String descricao) {
        this.pk_tipo_transacao = pk_tipo_transacao;
        this.descricao = descricao;
    }

    public int getPk_tipo_transacao() {
        return pk_tipo_transacao;
    }

    public void setPk_tipo_transacao(int pk_tipo_transacao) {
        this.pk_tipo_transacao = pk_tipo_transacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
