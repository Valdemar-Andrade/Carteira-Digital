/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author valdemar
 */
public class Transacao {
    
    private int pk_transacao, fk_conta_origem, fk_conta_destino, fk_tipo_transacao;
    private double valor;
    private String descricao, transationalID, estado_transacao;
    private Date data;

    public Transacao() {
    }

    public Transacao(int pk_transacao, int fk_conta_origem, int fk_conta_destino, int fk_tipo_transacao, double valor, String descricao, Date data, String transationalID, String estado_transacao) {
        this.pk_transacao = pk_transacao;
        this.fk_conta_origem = fk_conta_origem;
        this.fk_conta_destino = fk_conta_destino;
        this.fk_tipo_transacao = fk_tipo_transacao;
        this.valor = valor;
        this.descricao = descricao;
        this.data = data;
        this.estado_transacao = estado_transacao;
        this.transationalID = transationalID;
    }

    public int getPk_transacao() {
        return pk_transacao;
    }

    public void setPk_transacao(int pk_transacao) {
        this.pk_transacao = pk_transacao;
    }

    public int getFk_tipo_transacao() {
        return fk_tipo_transacao;
    }

    public void setFk_tipo_transacao(int fk_tipo_transacao) {
        this.fk_tipo_transacao = fk_tipo_transacao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public int getFk_conta_origem() {
        return fk_conta_origem;
    }

    public void setFk_conta_origem(int fk_conta_origem) {
        this.fk_conta_origem = fk_conta_origem;
    }

    public int getFk_conta_destino() {
        return fk_conta_destino;
    }

    public void setFk_conta_destino(int fk_conta_destino) {
        this.fk_conta_destino = fk_conta_destino;
    }

    public String getTransationalID() {
        return transationalID;
    }

    public void setTransationalID(String transationalID) {
        this.transationalID = transationalID;
    }

    public String getEstado_transacao() {
        return estado_transacao;
    }

    public void setEstado_transacao(String estado_transacao) {
        this.estado_transacao = estado_transacao;
    }

    @Override
    public String toString() {
        return "Transacao{" + "pk_transacao=" + pk_transacao + ", fk_conta_origem=" + fk_conta_origem + ", fk_conta_destino=" + fk_conta_destino + ", fk_tipo_transacao=" + fk_tipo_transacao + ", valor=" + valor + ", descricao=" + descricao + ", transationalID=" + transationalID + ", estado_transacao=" + estado_transacao + ", data=" + data + '}';
    }
    
}
