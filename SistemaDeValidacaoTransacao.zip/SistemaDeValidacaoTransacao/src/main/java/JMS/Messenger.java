/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JMS;

import DAO.ContaDAO;
import DAO.TipoTransacaoDAO;
import DAO.TransacaoDAO;
import Encriptador.EncriptadorRSA;
import Encriptador.EncriptadorRSA2;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.sql.Date;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import model.TipoTransacao;
import model.Transacao;
import org.apache.activemq.ActiveMQConnectionFactory;
import transacao.Main;

/**
 *
 * @author valdemar
 */
public class Messenger {

    private final String nomeTopico = "topico";
    int i = 1;

    public void inscreverNoTopico() {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageConsumer consumidor = session.createConsumer(topico);

            consumidor.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(Message mensagem) {
                    try {
                        if (mensagem instanceof TextMessage) {
                            TextMessage textMessage = (TextMessage) mensagem;
                            //Sistema de Validacao

                            //------ Tratamento do pedido da chave publica ------
                            if (textMessage.getBooleanProperty("pedidoChavePublica")) {
                                //Consultar a chave publica da conta com o correspondente IBAN
                                String chavePublica = new ContaDAO().getChavePublicaByIBAN(textMessage.getStringProperty("iban_beneficiario"));

                                //Enviar os dados da msg com a chave publica para ser encriptada
                                //Mensagem.iban_beneficiario, Mensagem.descricao, Mensagem.valor, Mensagem.conta_origem, chavePublica
                                enviarChavePublica(chavePublica, "chave_publica");
                                //System.out.println("\nA chave publica encontrada SistemaValidacao: " + chavePublica);
                            }

                            //System.out.println("Mensagem recebida do SA: " + textMessage.getText());
                            //Verifica a mensagem recebida com os dados da Transacao
                            if (textMessage.getBooleanProperty("transacao") == true) {
                                
                                //System.out.println("Entrou 1");

                                EncriptadorRSA encriptador = new EncriptadorRSA();

                                String chavePrivadaString = new ContaDAO().getChavePrivadaByIBAN(textMessage.getStringProperty("iban_beneficiario"));

                                byte[] chavePrivadaBytes = Base64.getDecoder().decode(chavePrivadaString);
                                PKCS8EncodedKeySpec chavePrivadaSpec = new PKCS8EncodedKeySpec(chavePrivadaBytes);

                                PrivateKey chavePrivada;

                                try {
                                    //Transformar a chave privada no formato string para PrivateKey
                                    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                                    chavePrivada = keyFactory.generatePrivate(chavePrivadaSpec);

                                    encriptador.setChavePrivada(chavePrivada);

                                    //System.out.println("IBAN beneficiario: " + textMessage.getStringProperty("iban_beneficiario"));
                                    //System.out.println("Conta origem criptografado: " + textMessage.getStringProperty("conta_origem"));
                                    //System.out.println("Valor criptografado: " + textMessage.getStringProperty("valor"));

                                    String v = textMessage.getStringProperty("valor");
                                    String c = textMessage.getStringProperty("conta_origem");

                                    byte[] decodedBytes = Base64.getDecoder().decode(v);
                                    byte[] decodedBytesConta = Base64.getDecoder().decode(c);
                                    //byte[] decodedBytesConta = hexToBytes(c);

                                    byte[] valorFinal = encriptador.desencriptar(decodedBytes, chavePrivada);
                                    byte[] contaOrigemFinal = encriptador.desencriptar(decodedBytesConta, chavePrivada);

                                    String valorFinalString = new String(valorFinal);
                                    String contaOrigemFinalString = new String(contaOrigemFinal);

                                    //System.out.println("Valor descriptografado: " + valorFinalString.trim()+ "\nConta origem descriptografado: " + contaOrigemFinalString.trim());
                                    
                                    double valor = Double.parseDouble(valorFinalString.trim());
                                    
                                    String iban_beneficiario = textMessage.getStringProperty("iban_beneficiario");
                                    String descricao = textMessage.getText();
                                    String conta_origem = contaOrigemFinalString.trim();
                                    
                                    efetuarTransacao(iban_beneficiario, descricao, valor, conta_origem);

                                    //System.out.println("Conta origem descriptografada: " + new String(encriptador.desencriptarRepartido(textMessage.getStringProperty("conta_origem").getBytes())));
                                    //System.out.println("Teste bytes: " + new String(textMessage.getStringProperty("conta_origem").getBytes()));
                                } catch (InvalidKeySpecException | NoSuchAlgorithmException | NumberFormatException ex) {
                                    Logger.getLogger(Messenger.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        }
                    } catch (JMSException e) {
                        e.printStackTrace();
                    }
                }
            });

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public byte[] hexToBytes(String hexString) {
        int length = hexString.length();
        byte[] result = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            String hexByte = hexString.substring(i, i + 2);
            int byteValue = Integer.parseInt(hexByte, 16);
            result[i / 2] = (byte) byteValue;
        }
        return result;
    }

    /*
    private byte[] desencriptarValor(EncriptadorRSA encriptador, String valor) {
        byte[] mensagemBytes = encriptador.desencriptarRepartido(valor.getBytes());
        return mensagemBytes;
    }*/
    public void enviarMensagem(String mensagem, String property) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);
            //Sistema de Validacao

            TextMessage msg = session.createTextMessage();
            msg.setText(mensagem);
            msg.setBooleanProperty(property, true);

            produtor.send(msg);

        } catch (JMSException e) {
        }
    }

    public void enviarChavePublica(String chavePublica, String property) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);
            //Sistema de Validacao

            TextMessage msg = session.createTextMessage();
            msg.setText(chavePublica);
            msg.setBooleanProperty(property, true);

            produtor.send(msg);

        } catch (JMSException e) {
        }
    }

    //
    private void efetuarTransacao(String iban_beneficiario, String descricao, double valor, String conta_origem) {

        //Transacao que vai ser registada para o transferidor (a debitar)
        Transacao transacao1 = new Transacao();

        //Transacao que vai ser registada para o receptor (a creditar)
        Transacao transacao2 = new Transacao();

        TransacaoDAO t = new TransacaoDAO();
        ContaDAO contaDao = new ContaDAO();

        //conta_origem -> numero_conta
        int pk_conta_destino = contaDao.getPkContaByIBAN(iban_beneficiario);
        int pk_conta_origem = contaDao.getPkContaByNumeroConta(conta_origem);
        Date data = null;

        int tipo_debito = 0, tipo_credito = 0;

        for (TipoTransacao tipo : new TipoTransacaoDAO().listarTipoTransacao()) {

            if (tipo.getDescricao().equalsIgnoreCase("debito")) {
                tipo_debito = tipo.getPk_tipo_transacao();
            } else {
                tipo_credito = tipo.getPk_tipo_transacao();
            }
        }

        //Transferidor - Debito
        transacao1.setTransationalID("");
        transacao1.setValor(valor);
        transacao1.setDescricao(descricao);
        transacao1.setData(data);
        transacao1.setEstado_transacao("Processando");
        transacao1.setFk_conta_origem(pk_conta_origem);
        transacao1.setFk_conta_destino(pk_conta_destino);
        transacao1.setFk_tipo_transacao(tipo_debito);

        //Receptor - Credito
        transacao2.setTransationalID("");
        transacao2.setValor(valor);
        transacao2.setDescricao(descricao);
        transacao2.setData(data);
        transacao2.setEstado_transacao("Processando");
        transacao2.setFk_conta_origem(pk_conta_origem);
        transacao2.setFk_conta_destino(pk_conta_destino);
        transacao2.setFk_tipo_transacao(tipo_credito);

        //Alterar os saldos das Contas Origem e Destino
        double saldo_conta_origem = contaDao.getSaldoConta(pk_conta_origem);
        double saldo_conta_destino = contaDao.getSaldoConta(pk_conta_destino);

        //Consultar o saldo da conta destino para calcular o novo saldo
        if (pk_conta_destino != pk_conta_origem) {
            //A moeda destino e igual a moeda origem
            if (contaDao.getMoedaConta(pk_conta_destino) == contaDao.getMoedaConta(pk_conta_origem)) {

                //
                if (saldo_conta_origem >= valor && contaDao.getEstadoConta(pk_conta_origem).equalsIgnoreCase("aberta")) {
                    //JOptionPane.showMessageDialog(null, "Conta esta: " + contaDao.getEstadoConta(pk_conta_origem));

                    //Alterar saldo origem - Debito (origem)
                    contaDao.editarSaldoDisponivelByConta(pk_conta_origem, (saldo_conta_origem - valor));
                    contaDao.editarSaldoContabilisticoByConta(pk_conta_origem, (saldo_conta_origem - valor));

                    //Alterar saldo destino - Credito (destino)
                    contaDao.editarSaldoDisponivelByConta(pk_conta_destino, (saldo_conta_destino + valor));
                    contaDao.editarSaldoContabilisticoByConta(pk_conta_destino, (saldo_conta_destino + valor));

                    transacao1.setEstado_transacao("Sucesso");
                    transacao2.setEstado_transacao("Sucesso");

                    //Enfim cadastrar as transacoes
                    t.cadastrarTransacao(transacao1);
                    t.cadastrarTransacao(transacao2);

                    enviarMensagem("Sucesso", "confirmacaoID");

                    //Apresentar na tabela a transacao
                    Main.tableModel.addRow(new Object[]{"" + i, "" + transacao1.getDescricao(), "" + transacao1.getEstado_transacao()});
                    i++;

                } else {
                    transacao1.setEstado_transacao("Falhou");
                    //transacao2.setEstado_transacao("Falhou");

                    t.cadastrarTransacao(transacao1);
                    //t.cadastrarTransacao(transacao2);

                    enviarMensagem("Falhou", "confirmacaoID");

                    //Apresentar na tabela a transacao
                    Main.tableModel.addRow(new Object[]{"" + i, "" + transacao1.getDescricao(), "" + transacao1.getEstado_transacao()});
                    i++;
                }
            } else {
                //Precisa se fazer uma conversao das moedas
            }
        } else {
            //Transferencia para a mesma conta! deve ser negada

            transacao1.setEstado_transacao("Falhou");

            t.cadastrarTransacao(transacao1);

            enviarMensagem("Falhou", "confirmacaoID");

            //Apresentar na tabela a transacao
            Main.tableModel.addRow(new Object[]{"" + i, "" + transacao1.getDescricao(), "" + transacao1.getEstado_transacao()});
            i++;
        }

    }

    public void enviarMensagemCriptografada(String iban_beneficiario, String descricao, double valor, String conta_origem, String chave_publica) {
        try {
            String brokerURL = "tcp://localhost:61616";

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topico = session.createTopic(nomeTopico);

            MessageProducer produtor = session.createProducer(topico);

            //Elaborar a mensagem com dados da Transacao e enviar para o Sistema de Validacao
            TextMessage msg = session.createTextMessage();
            msg.setText(descricao);
            msg.setStringProperty("iban_beneficiario", iban_beneficiario);
            msg.setDoubleProperty("valor", valor);
            msg.setStringProperty("conta_origem", conta_origem);
            msg.setBooleanProperty("transacao", true);

            //Criptografar a msg
            EncriptadorRSA encriptador = new EncriptadorRSA();

            String mensagemEncriptar = msg.toString();
            System.out.println("Mensagem antes: " + mensagemEncriptar);

            byte[] encriptada = encriptador.encriptar(mensagemEncriptar.getBytes());
            String encoded = Base64.getEncoder().encodeToString(encriptada);

            produtor.send(session.createTextMessage(encoded));

        } catch (JMSException e) {
        }
    }

    public String getNomeTopico() {
        return nomeTopico;
    }

}
