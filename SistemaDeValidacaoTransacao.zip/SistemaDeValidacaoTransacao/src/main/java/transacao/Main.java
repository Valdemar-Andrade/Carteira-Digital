/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transacao;

import JMS.Messenger;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.ConnectException;
import java.util.ArrayList;
import javax.jms.JMSException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author valdemar
 */
public class Main extends JFrame{
    
    
    
    
    public Main(){
        configurarJanela();
        new Messenger().inscreverNoTopico();
    }
    
    public static DefaultTableModel tableModel = new DefaultTableModel();

    JTable tabela = new JTable(tableModel);

    public JPanel painelTop() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JLabel lbl = new JLabel("Tabela Informativa Das Transacoes");

        painel.add(lbl);

        return painel;
    }

    public JPanel painelCentro() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        tableModel.addColumn("ID");
        tableModel.addColumn("Descricao");
        tableModel.addColumn("Estado");

        painel.add(new JScrollPane(tabela));

        return painel;
    }
    
    private void configurarJanela(){
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        this.setLayout(new BorderLayout());
        this.add(painelTop(), BorderLayout.NORTH);
        this.add(painelCentro(), BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    public static void main(String args[]){
        
        Main m = new Main();
    }
    
}
