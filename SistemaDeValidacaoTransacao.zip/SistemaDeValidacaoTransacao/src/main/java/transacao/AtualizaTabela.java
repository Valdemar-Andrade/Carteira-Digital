/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transacao;


/**
 *
 * @author valdemar
 */
public class AtualizaTabela extends Thread {

    @Override
    public void run() {
        try {
            while (true) {
                
                atualizar();

                sleep(2500);
            }

        } catch (InterruptedException ex) {
        }
    }

    private void atualizar() {
        Main.tableModel.setRowCount(0);
    }

}
