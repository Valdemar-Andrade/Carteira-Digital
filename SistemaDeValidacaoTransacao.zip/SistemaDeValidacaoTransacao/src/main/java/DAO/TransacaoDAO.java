/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import model.Transacao;

/**
 *
 * @author valdemar
 */
public class TransacaoDAO {
    
    public void cadastrarTransacao(Transacao transacao) {
        
        //JOptionPane.showMessageDialog(null, "Transacao: " + transacao.toString());
        
        String query_insert = "INSERT INTO transacao VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?, ?)";
        String data = java.time.LocalDate.now().toString();
        Date dataTransacao = Date.valueOf(data);
        
        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, transacao.getTransationalID());
            ps.setDouble(2, transacao.getValor());
            ps.setString(3, transacao.getDescricao());
            ps.setDate(4, dataTransacao);
            ps.setString(5, transacao.getEstado_transacao());
            ps.setInt(6, transacao.getFk_conta_origem());
            ps.setInt(7, transacao.getFk_conta_destino());
            ps.setInt(8, transacao.getFk_tipo_transacao());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    //select p.nome, cl.pk_cliente from carteira c join pessoa p on c.fk_conta = p.fk_conta join cliente cl on cl.fk_pessoa = p.pk_pessoa where c.endereco = 'maria@gmail.com';
    
    //Retorna a chave de um cliente a partir de um endereco de carteira
    public int getClienteByEnderecoCartaoPk(String endereco) {

        String query = "SELECT cl.pk_cliente FROM carteira c JOIN pessoa p ON c.fk_conta = p.fk_conta JOIN cliente cl on cl.fk_pessoa = p.pk_pessoa JOIN carteira_cartao_moeda ccm on c.pk_carteira = ccm.fk_carteira JOIN cartao cart on ccm.fk_cartao = cart.pk_cartao WHERE cart.numero_cartao=?";
        int pk_cliente = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, endereco);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pk_cliente = rs.getInt(1);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return pk_cliente;
    }
    
    
}
