/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Moeda;

/**
 *
 * @author valdemar
 */
public class MoedaDAO {
    
    public boolean cadastrarMoeda(Moeda moeda) {
        
        String query_insert = "INSERT INTO moeda VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, moeda.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarMoeda(int id, String valor){
        String query = "update moeda set descricao=? where pk_moeda=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarMoeda(int id){
        String query = "delete from moeda where pk_moeda=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Moeda> listarMoeda() {
        ArrayList<Moeda> listaMoeda = new ArrayList<>();
        String query = "SELECT pk_moeda, descricao FROM moeda";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Moeda moeda = new Moeda();

                moeda.setPk_moeda(rs.getInt(1));
                moeda.setDescricao(rs.getString(2));

                listaMoeda.add(moeda);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaMoeda;
    }
    
//    public Moeda getMoedaByConta(int pk_conta){
//        
//        String query = "SELECT pk_moeda FROM moeda WHERE fk_conta=?";
//        Moeda moeda = new Moeda();
//
//        try {
//            Connection con = Conexao.abrirConexao();
//            PreparedStatement ps = con.prepareStatement(query);
//            
//            ps.setInt(1, pk_conta);
//            
//            ResultSet rs = ps.executeQuery();
//
//            if (rs.next()) {
//                moeda.setPk_moeda(rs.getInt(1));
//            }
//
//            rs.close();
//            ps.close();
//        } catch (SQLException ex) {
//            ex.getMessage();
//        }
//
//        return moeda;
//        
//    }
    
}
