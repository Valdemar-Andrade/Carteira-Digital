/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Conta;

/**
 *
 * @author valdemar
 */
public class ContaDAO {
    
    public void criarConta(Conta conta){
        
        String query_insert = "INSERT INTO conta VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, conta.getNumero_conta());
            ps.setString(2, conta.getIban());
            ps.setDouble(3, conta.getSaldo_contabilistico());
            ps.setDouble(4, conta.getSaldo_disponivel());
            ps.setString(5, conta.getEstado_conta());
            ps.setString(6, conta.getChave_privada());
            ps.setString(7, conta.getChave_publica());
            
            ps.execute();

            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        
    }
    
    public int getUltimaContaPk(){
        
        String query = "SELECT MAX(pk_conta) FROM conta";
        
        int pk_conta = 0;
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                pk_conta = rs.getInt(1);
            }
            
        }catch(SQLException ex){}
        
        return pk_conta;
    }
    
    public String getContaIBAN(int pk_login){
        String query = "SELECT iban FROM conta con JOIN cliente cli ON con.pk_conta=cli.fk_conta JOIN login log ON log.pk_login=cli.fk_login WHERE log.pk_login=?";
        String iban = "";
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pk_login);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                iban = rs.getString(1);
            }
        }catch(SQLException ex){}
        
        return iban;
    }
    
    public String getContaNumero(int pk_login){
        String query = "SELECT numero_conta FROM conta con JOIN cliente cli ON con.pk_conta=cli.fk_conta JOIN login log ON log.pk_login=cli.fk_login WHERE log.pk_login=?";
        String numero_conta = "";
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pk_login);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                numero_conta = rs.getString(1);
            }
        }catch(SQLException ex){}
        
        return numero_conta;
    }
    
    public int getPkContaByNumeroConta(String conta_origem) {

        String query = "SELECT pk_conta FROM conta WHERE numero_conta=?";
        int pk_conta = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, conta_origem);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pk_conta = rs.getInt(1);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return pk_conta;
    }
    
    public int getPkContaByIBAN(String iban_beneficiario) {

        String query = "SELECT pk_conta FROM conta WHERE iban=?";
        int pk_conta = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, iban_beneficiario);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pk_conta = rs.getInt(1);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return pk_conta;
    }
    
    public double getSaldoConta(int pk_conta){
        
        String query = "SELECT saldo_disponivel FROM conta WHERE pk_conta=?";
        double saldo = 0.0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_conta);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                saldo = rs.getDouble(1);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return saldo;
    }
    
    public void editarSaldoDisponivelByConta(int pk_conta, double novo_saldo){
        
        String query_editar = "UPDATE conta set saldo_disponivel=? WHERE pk_conta=?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_editar);

            ps.setDouble(1, novo_saldo);
            ps.setInt(2, pk_conta);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        
    }
    
    public void editarSaldoContabilisticoByConta(int pk_conta, double novo_saldo){
        
        String query_editar = "UPDATE conta set saldo_contabilistico=? WHERE pk_conta=?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_editar);

            ps.setDouble(1, novo_saldo);
            ps.setInt(2, pk_conta);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        
    }
    
    public String getMoedaContaByLogin(int pk_login){
        
        String query = "SELECT m.descricao FROM conta c JOIN moeda m ON c.fk_moeda=m.pk_moeda JOIN cliente cli ON cli.fk_conta=c.pk_conta JOIN login l ON l.pk_login=cli.fk_login WHERE l.pk_login=?";
        String moeda = "";
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pk_login);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                moeda = rs.getString(1);
            }
        }catch(SQLException ex){}
        
        //JOptionPane.showMessageDialog(null, "pk_conta: " + pk_login + " moeda: " + moeda);
        return moeda;
        
    }
    
    public int getMoedaConta(int pk_conta){
        
        String query = "SELECT m.pk_moeda FROM conta c JOIN moeda m ON c.fk_moeda=m.pk_moeda WHERE c.pk_conta=?";
        int moeda = 0;
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pk_conta);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                moeda = rs.getInt(1);
            }
        }catch(SQLException ex){}
        
        //JOptionPane.showMessageDialog(null, "pk_conta: " + pk_login + " moeda: " + moeda);
        return moeda;
        
    }
    
    public String getEstadoConta(int pk_conta){
        
        String query = "SELECT estado_conta FROM conta WHERE pk_conta=?";
        String estado_conta = "";
        
        try{
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pk_conta);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                estado_conta = rs.getString(1);
            }
        }catch(SQLException ex){}
        
        return estado_conta;
        
    }
    
    public String getChavePublicaByIBAN(String iban){
        String query = "SELECT chave_publica FROM conta WHERE iban=?";
        String chavePublica = "";
        
        Connection con = Conexao.abrirConexao();
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, iban);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                chavePublica = rs.getString(1);
            }
        } catch (SQLException ex) {}
        
        return chavePublica;
    }
    
    public String getChavePrivadaByIBAN(String iban){
        String query = "SELECT chave_privada FROM conta WHERE iban=?";
        String chavePrivada = "";
        
        Connection con = Conexao.abrirConexao();
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, iban);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                chavePrivada = rs.getString(1);
            }
        } catch (SQLException ex) {}
        
        return chavePrivada;
    }
    
}
